package com.taskapplication.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String username;
    private String status;
    private Date date;
    private String priority;
    private String description;
    
    
    
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Task(String username, String status, Date date, String priority, String description) {
		super();
		this.username = username;
		this.status = status;
		this.date = date;
		this.priority = priority;
		this.description = description;
	}
	
	 // Getters and Setters
	public String getUserName() {
		return username;
	}
	public void setUserName(String username) {
		this.username = username;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
    
}
