package com.taskapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taskapplication.model.Booking;
import com.taskapplication.model.Task;

import java.util.List;

public interface AssigningRepository extends JpaRepository<Assigning, Long> {
    
}
