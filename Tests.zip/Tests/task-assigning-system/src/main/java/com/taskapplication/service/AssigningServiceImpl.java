package com.taskapplication.service;

import com.taskapplication.model.Assigning;
import com.taskapplication.repository.AssigningRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssigningServiceImpl implements AssigningService {

    @Autowired
    private AssigningRepository bookingRepository;

    @Override
    public String bookFlight(Assigning booking) {
        assigningRepository.save(booking);
        return "Booking confirmed!";
    }
}
