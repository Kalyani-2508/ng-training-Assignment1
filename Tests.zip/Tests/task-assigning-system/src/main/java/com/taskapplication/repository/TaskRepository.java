package com.taskapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taskapplication.model.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {
    Task findByUsername(String username);  // Find user by username
}
