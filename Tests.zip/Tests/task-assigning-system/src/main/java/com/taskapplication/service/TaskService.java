package com.taskapplication.service;

import com.taskapplication.model.Task;

public interface TaskService {
    void newTask(Task task);    
}
