package com.taskapplication.service;

import com.taskapplication.model.Task;
import com.taskapplication.repository.TaskRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Override
    public void newTask(Task task) {
        TaskRepository.save(task);  // Save user to the database
    }
    
}
