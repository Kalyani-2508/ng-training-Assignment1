package com.taskapplication.service;

import com.taskapplication.model.Assigning;

public interface AssigningService {
    String bookFlight(Assigning assigning);
}
