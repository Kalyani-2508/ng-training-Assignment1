package com.taskapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskAssigningSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskAssigningSystemApplication.class, args);
	}

}
