package com.taskapplication.controller;

import com.taskapplication.model.Task;
import com.taskapplication.service.TaskService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping("/newtask")
    public ResponseEntity<String> registerUser(@RequestBody Task task) {
        try {
            taskService.newTask(task);
            return new ResponseEntity<>("Task assigned successfully!", HttpStatus.OK); // Success response
        } catch (Exception e) {
            return new ResponseEntity<>("Assigning failed: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR); // Error response
        }
    }
    
}
