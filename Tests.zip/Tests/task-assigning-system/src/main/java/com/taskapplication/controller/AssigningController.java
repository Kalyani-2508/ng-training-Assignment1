package com.taskapplication.controller;

import com.taskapplication.model.Assigning;
import com.taskapplication.service.AssigningService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tasks")
public class AssigningController {

    @Autowired
    private AssigningService assigningService;

    @PostMapping("/task")
    public String bookFlight(@RequestBody Assigning assigning) {
        return assigningService.bookFlight(assigning);
    }
}
